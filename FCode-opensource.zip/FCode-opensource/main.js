const { app, BrowserWindow, Menu, ipcMain } = require('electron');
const path = require('path');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 800,
    height: 600,
    icon: path.join(__dirname, 'FCode.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'renderer.js'),
      contextIsolation: false,
      enableRemoteModule: true,
      nodeIntegration: true,
    },
  });

  mainWindow.setMinimumSize(600, 400);

  mainWindow.loadFile('index.html');

  const isMac = process.platform === 'darwin';

  const template = [
    ...(isMac ? [{
      label: app.name,
      submenu: [
        { role: 'about' },
        { type: 'separator' },
        { role: 'services' },
        { type: 'separator' },
        { role: 'hide' },
        { role: 'hideothers' },
        { role: 'unhide' },
        { type: 'separator' },
        { role: 'quit' }
      ]
    }] : []),
    {
      label: 'File',
      submenu: [
        {
          label: 'Save',
          accelerator: 'CmdOrCtrl+S',
          click: () => {
            mainWindow.webContents.send('file-save');
          }
        },
        {
          label: 'Save As',
          click: () => {
            mainWindow.webContents.send('file-save-as');
          }
        },
        {
          label: 'Load',
          click: () => {
            mainWindow.webContents.send('file-load');
          }
        },
        { type: 'separator' },
        {
          id: 'settings',
          label: 'Settings',
          click: () => {
            createSettingsWindow();
          }
        },
        isMac ? { role: 'close' } : { role: 'quit' }
      ]
    },
    {
      label: 'Edit',
      submenu: [
        { role: 'undo' },
        { role: 'redo' },
        { type: 'separator' },
        { role: 'cut' },
        { role: 'copy' },
        { role: 'paste' },
        ...(isMac ? [
          { role: 'pasteAndMatchStyle' },
          { role: 'delete' },
          { role: 'selectAll' },
          { type: 'separator' },
          {
            label: 'Speech',
            submenu: [
              { role: 'startspeaking' },
              { role: 'stopspeaking' }
            ]
          }
        ] : [
          { role: 'delete' },
          { type: 'separator' },
          { role: 'selectAll' }
        ])
      ]
    },
    {
      label: 'View',
      submenu: [
        { role: 'reload' },
        { role: 'forcereload' },
        { role: 'togglefullscreen' }
      ]
    },
    {
      role: 'window',
      submenu: [
        { role: 'minimize' },
        { role: 'zoom' },
        ...(isMac ? [
          { type: 'separator' },
          { role: 'front' },
          { type: 'separator' },
          { role: 'window' }
        ] : [
          { role: 'close' }
        ])
      ]
    },
    {
      role: 'help',
      submenu: [
        {
          label: 'Github',
          click: async () => {
            const { shell } = require('electron')
            await shell.openExternal('https://github.com/FrankoGames/FCode')
          }
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

function createSettingsWindow() {
  let settingsWindow = new BrowserWindow({
    width: 300,
    height: 150,
    modal: false,
    frame: true,
    resizable: false,
    movable: true,
    icon: path.join(__dirname, 'FCode.ico'),
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: true
    }
  });

  settingsWindow.loadFile('settings.html');

  settingsWindow.once('ready-to-show', () => {
    settingsWindow.show();
  });
  settingsWindow.on('closed', () => {
    settingsWindow = null;
    enableSettingsMenuItem();
  });

  
  disableSettingsMenuItem();
}

function enableSettingsMenuItem() {
  const settingsMenuItem = Menu.getApplicationMenu().getMenuItemById('settings');
  if (settingsMenuItem) {
    settingsMenuItem.enabled = true;
  }
}

function disableSettingsMenuItem() {
  const settingsMenuItem = Menu.getApplicationMenu().getMenuItemById('settings');
  if (settingsMenuItem) {
    settingsMenuItem.enabled = false;
  }
}
