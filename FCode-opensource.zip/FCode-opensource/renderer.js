const { ipcRenderer } = require('electron');
const { dialog } = require('electron').remote;
const fs = require('fs');

let currentFilePath = null;

document.getElementById('editor').addEventListener('keydown', (e) => {
    Prism.highlightAll();
  if ((e.ctrlKey || e.metaKey) && e.key === 's') {
    e.preventDefault();
    saveFile();
  }
});

ipcRenderer.on('file-save', () => {
  saveFile();
});

ipcRenderer.on('file-save-as', () => {
  saveFileAs();
});

ipcRenderer.on('file-load', () => {
  loadFile();
});

function saveFile() {
  if (currentFilePath) {
    const content = document.getElementById('editor').value;
    fs.writeFile(currentFilePath, content, (err) => {
      if (err) {
        alert('An error occurred while saving the file');
      }
    });
  } else {
    saveFileAs();
  }
}

function saveFileAs() {
  dialog.showSaveDialog({
    title: 'Save your file',
    defaultPath: 'example.txt'
  }).then(result => {
    if (!result.canceled) {
      currentFilePath = result.filePath;
      const content = document.getElementById('editor').value;
      fs.writeFile(currentFilePath, content, (err) => {
        if (err) {
          alert('An error occurred while saving the file');
        }
      });
    }
  }).catch(err => {
    console.log(err);
  });
}

function loadFile() {
  dialog.showOpenDialog({
    properties: ['openFile']
  }).then(result => {
    if (!result.canceled) {
      currentFilePath = result.filePaths[0];
      fs.readFile(currentFilePath, 'utf-8', (err, data) => {
        if (err) {
          alert('An error occurred while loading the file');
        } else {
          document.getElementById('editor').value = data;
        }
      });
    }
  }).catch(err => {
    console.log(err);
  });
}

ipcRenderer.on('toggle-dark-mode', (event, isEnabled) => {
    if (isEnabled) {
      document.body.classList.add('dark-mode');
    } else {
      document.body.classList.remove('dark-mode');
    }
  });